package com.example.berg_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
